#Import the pygame library and initialise the game engine
import pygame
#Let's import the Paddle Class & the Ball Class
from paddle import Paddle
from ball import Ball
from brick import Brick
 
pygame.init()
 
# Define some colors
WHITE = (255,255,255)
DARKBLUE = (36,90,190)
LIGHTBLUE = (0,176,240)
RED = (255,0,0)
ORANGE = (255,100,0)
YELLOW = (255,255,0)
BROWN = (125, 75, 14)
GRAY = (128,128,128)
GREEN = (13, 110, 0)
PINK = (255,128,128)
BLACK = (0,0,0)
 
score = 0
lives = 3
 
# Open a new window
size = (1280, 720)
screen = pygame.display.set_mode(size)
pygame.display.set_caption("Revenge Studios - BIT.TRIP BREAKOUT v0.5")
 
#This will be a list that will contain all the sprites we intend to use in our game.
all_sprites_list = pygame.sprite.Group()
 
#Create the Paddle
paddle = Paddle(WHITE, 100, 25)
paddle.rect.x = 350
paddle.rect.y = 560
 
#Create the ball sprite
ball = Ball(WHITE,20,20)
ball.rect.x = 345
ball.rect.y = 195
 
all_bricks = pygame.sprite.Group()
for i in range(11):
    brick = Brick(WHITE,100,43)
    brick.rect.x = 100 + i* 100
    brick.rect.y = 60
    all_sprites_list.add(brick)
    all_bricks.add(brick)
for i in range(11):
    brick = Brick(PINK,100,42)
    brick.rect.x = 100 + i* 100
    brick.rect.y = 100
    all_sprites_list.add(brick)
    all_bricks.add(brick)
for i in range(11):
    brick = Brick(RED,100,40)
    brick.rect.x = 100 + i* 100
    brick.rect.y = 140
    all_sprites_list.add(brick)
    all_bricks.add(brick)
 
# Add the paddle to the list of sprites
all_sprites_list.add(paddle)
all_sprites_list.add(ball)

def text_objects(text, font):
    textSurface = font.render(text, True, black)
    return textSurface, textSurface.get_rect()
 
def message_display(text):
    largeText = pygame.font.Font('bittrip.ttf',115)
    TextSurf, TextRect = text_objects(text, largeText)
    TextRect.center = ((display_width/2),(display_height/2))
    gameDisplay.blit(TextSurf, TextRect)
 
    pygame.display.update()
 
    time.sleep(2)
 
    game_loop()

def game_intro():

    intro = True

    while intro:
        for event in pygame.event.get():
            print(event)
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                
        gameDisplay.fill(white)
        largeText = pygame.font.Font('bittrip.ttf',40)
        TextSurf, TextRect = text_objects("BIT.TRIP BREAKOUT", largeText)
        TextRect.center = ((display_width/2),(display_height/2))
        gameDisplay.blit(TextSurf, TextRect)
        pygame.display.update()
        clock.tick(15)

 
# The loop will carry on until the user exit the game (e.g. clicks the close button).
carryOn = True
 
# The clock will be used to control how fast the screen updates
clock = pygame.time.Clock()
 
# -------- Main Program Loop -----------
while carryOn:
    # --- Main event loop
    for event in pygame.event.get(): # User did something
        if event.type == pygame.QUIT: # If user clicked close
              carryOn = False # Flag that we are done so we exit this loop
 
    #Moving the paddle when the use uses the arrow keys
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        paddle.moveLeft(10)
    if keys[pygame.K_RIGHT]:
        paddle.moveRight(10)
    if keys[pygame.K_q]:
      font = pygame.font.Font('bit-trip.ttf', 40)
      text = font.render("LEVEL.COMPLETE", 1, GREEN)
      screen.blit(text, (300,300))
      text = font.render("SCORE: ", str(score), 1, WHITE)
      screen.blit(text, (640,400))
      pygame.display.flip()
      pygame.time.wait(3000)
      pygame.quit()
 
 
    # --- Game logic should go here
    all_sprites_list.update()
 
    #Check if the ball is bouncing against any of the 4 walls:
    if ball.rect.x>=1280:
        ball.velocity[0] = -ball.velocity[0]
    if ball.rect.x<=0:
        ball.velocity[0] = -ball.velocity[0]
    if ball.rect.y>710:
        ball.velocity[1] = -ball.velocity[1]
        lives -= 1
        if lives == 0:
            #Display Game Over Message for 3 seconds
            font = pygame.font.Font('bit-trip.ttf', 74)
            text = font.render("GAME OVER", 1, RED)
            screen.blit(text, (300,300))
            pygame.display.flip()
            pygame.time.wait(3000)
 
            #Stop the Game
            carryOn=False
 
    if ball.rect.y<40:
        ball.velocity[1] = -ball.velocity[1]
 
    #Detect collisions between the ball and the paddles
    if pygame.sprite.collide_mask(ball, paddle):
      ball.rect.x -= ball.velocity[0]
      ball.rect.y -= ball.velocity[1]
      ball.bounce()
 
    #Check if there is the ball collides with any of bricks
    brick_collision_list = pygame.sprite.spritecollide(ball,all_bricks,False)
    for brick in brick_collision_list:
      ball.bounce()
      score += 1
      brick.kill()
      if len(all_bricks)==0:
           #Display Level Complete Message for 3 seconds
            font = pygame.font.Font('bit-trip.ttf', 54)
            text = font.render("LEVEL.COMPLETE", 1, GREEN)
            screen.blit(text, (300,300))
            text = font.render("SCORE: ", str(score), 1, WHITE)
            screen.blit(text, (640,400))
            pygame.display.flip()
            pygame.time.wait(3000)
 
            #Stop the Game
            carryOn=False
 
    # --- Drawing code should go here
    # First, clear the screen to dark blue.
    screen.fill(BLACK)
    pygame.draw.line(screen, WHITE, [0, 50], [1280, 50], 10)
 
    #Display the score and the number of lives at the top of the screen
    font = pygame.font.Font('bit-trip.ttf', 15)
    text = font.render(str(score), 1, WHITE)
    screen.blit(text, (20,5))
    text = font.render("MISSES.LEFT: " + str(lives), 1, WHITE)
    screen.blit(text, (1030,5))
    text = font.render("NETHER", 1, WHITE)
    screen.blit(text, (575,5))
 
    #Now let's draw all the sprites in one go. (For now we only have 2 sprites!)
    all_sprites_list.draw(screen)
 
    # --- Go ahead and update the screen with what we've drawn.
    pygame.display.flip()
 
    # --- Limit to 60 frames per second
    clock.tick(60)
 
#Once we have exited the main program loop we can stop the game engine:
pygame.quit()